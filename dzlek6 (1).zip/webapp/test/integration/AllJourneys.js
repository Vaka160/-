/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zjblessons/worklist/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zjblessons/worklist/test/integration/pages/Worklist",
	"zjblessons/worklist/test/integration/pages/Object",
	"zjblessons/worklist/test/integration/pages/NotFound",
	"zjblessons/worklist/test/integration/pages/Browser",
	"zjblessons/worklist/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zjblessons.worklist.view."
	});

	sap.ui.require([
		"zjblessons/worklist/test/integration/WorklistJourney",
		"zjblessons/worklist/test/integration/ObjectJourney",
		"zjblessons/worklist/test/integration/NavigationJourney",
		"zjblessons/worklist/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});